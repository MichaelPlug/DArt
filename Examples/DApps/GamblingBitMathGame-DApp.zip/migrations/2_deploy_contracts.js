const GamblingBitMathGame = artifacts.require("GamblingBitMathGame");

module.exports = function (deployer) {
  deployer.deploy(GamblingBitMathGame, 3, {value: 5});
  // Seed and initial contribution
};

